# Quick Implementation Guide - Case Management

## Current Architecture (Verified via API)

**EspoCRM URL:** `https://espocrm-dev-220642639797.us-central1.run.app`

### Existing Fields ✅
- `number` - Auto-increment case ID
- `cCaseNumber` - Custom case number (format: CDDMMYYYYNNNNN)
- `name` - Case subject
- `status` - Currently: New, Assigned, Pending, Closed, Rejected, Duplicate
- `priority` - Currently: Low, Normal, High, Urgent
- `type` - Currently: Question, Incident, Problem
- `contactId` - Customer link
- `assignedUserId` - Assigned officer

### Missing Fields ❌
- `cCustomerType` - Customer Type (Individual/Corporate/SME/Micro Finance)
- `cProductType` - Product Type (Personal Loan, Vehicle Loan, etc.)
- `cBranchId` - Branch link

---

## Step-by-Step Implementation (5 Days)

### Day 1: Field Creation

#### Step 1.1: Create cCustomerType Field
```
Administration → Entity Manager → Case → Fields → Create Field

Name: cCustomerType
Label: Customer Type
Type: Enum
Options:
  - Individual
  - Corporate
  - SME
  - Micro Finance
Default: Individual
Audited: Yes
```

#### Step 1.2: Create cProductType Field
```
Administration → Entity Manager → Case → Fields → Create Field

Name: cProductType
Label: Product Type
Type: Enum
Options:
  - Personal Loan
  - Vehicle Loan
  - Gold Loan
  - Home Loan
  - Business Loan
  - Leasing
  - Pawning
  - Savings Account
  - Fixed Deposit
  - Other
Audited: Yes
```

#### Step 1.3: Create Branch Relationship
```
Administration → Entity Manager → Case → Relationships → Create

Relationship Type: Many-to-One
Link Name: cBranch
Foreign Entity: Branch
Foreign Link Name: cases
```

#### Step 1.4: Update Case Category (type field)
```
Administration → Entity Manager → Case → Fields → type → Edit

Update Options to:
  - Service
  - Complaint
  - Inquiry
  
Administration → Label Manager → Case → options → type
Update translations:
  Service → Service Request
  Complaint → Customer Complaint
  Inquiry → General Inquiry
```

#### Step 1.5: Update Case Status
```
Administration → Entity Manager → Case → Fields → status → Edit

Update Options to:
  - Open
  - In Progress
  - Pending Customer
  - Escalated
  - Resolved
  - Closed

Default: Open

Set styles:
  Open → primary (blue)
  In Progress → warning (orange)
  Pending Customer → default (gray)
  Escalated → danger (red)
  Resolved → success (green)
  Closed → default (gray)
```

### Day 2: Layout Configuration

#### Step 2.1: Update Detail Layout
```
Administration → Entity Manager → Case → Layouts → Detail

Panel 1: Case Information
  Row 1: name, status
  Row 2: type, priority
  Row 3: cCustomerType, cProductType
  Row 4: cBranch, assignedUser
  Row 5: contact

Panel 2: Description
  Row 1: description (full width)

Panel 3: System Information
  Row 1: number, cCaseNumber
  Row 2: createdAt, modifiedAt
```

#### Step 2.2: Update List Layout
```
Administration → Entity Manager → Case → Layouts → List

Columns:
  - number (width: 10%)
  - name (width: 25%, link: Yes)
  - type (width: 12%)
  - status (width: 12%)
  - priority (width: 10%)
  - contactName (width: 15%)
  - assignedUserName (width: 12%)
  - createdAt (width: 12%)
```

#### Step 2.3: Configure Filters
```
Administration → Entity Manager → Case → Layouts → Filters

Add filters:
  - status
  - priority
  - type
  - cCustomerType
  - cProductType
  - cBranch
  - assignedUser
  - contact
  - createdAt
```

### Day 3: Formula Scripts

#### Step 3.1: Before-Save Formula
```
Administration → Entity Manager → Case → Formula → Edit

// Auto-populate customer type from contact
$contactId = entity\attribute('contactId');

if($contactId && !entity\attribute('cCustomerType')) {
  entity\setAttribute('cCustomerType', 'Individual');
}
```

#### Step 3.2: After-Save Formula
```
// Handle escalation
$statusChanged = entity\isAttributeChanged('status');
$isEscalated = entity\attribute('status') == 'Escalated';

if($statusChanged && $isEscalated) {
  $userId = entity\attribute('assignedUserId');
  $supervisor = record\attribute('User', $userId, 'superiorId');
  
  if($supervisor) {
    entity\setAttribute('assignedUserId', $supervisor);
  }
}
```

### Day 4: BPM Workflows

#### Step 4.1: Import Workflows
```
Administration → Import

Entity Type: Process Flowchart
File: case_workflows_complete.csv
Import Options:
  - Skip duplicates: Yes
  - Run in idle: No
  
Click: Review → Run Import
```

#### Step 4.2: Activate Workflows
```
Administration → Flowcharts

For each workflow:
  1. Case: Auto-Assignment & Acknowledgment
  2. Case: Status Change Handling
  3. Case: Priority Alert System

Actions:
  - Open flowchart
  - Check "Is Active"
  - Save
```

#### Step 4.3: Configure Teams
```
Administration → Teams → Create Team

Team 1: Customer Service Team
Team 2: Complaints Handling Team
Team 3: General Inquiry Team

For each team:
  - Add team members
  - Set roles
  - Configure permissions
```

### Day 5: Testing

#### Test 1: Create Case via Web UI
```
Cases → Create Case

Fill in:
  Subject: Test complaint - internet banking
  Category: Complaint
  Priority: High
  Customer Name: [Select existing contact]
  Customer Type: Individual
  Product Type: Savings Account
  Branch: [Select branch]
  Description: Test description

Expected Results:
  ✓ Auto-assigned to complaints team member
  ✓ Status changed to "In Progress"
  ✓ Case number generated (CDDMMYYYYNNNNN)
  ✓ Email notification sent
```

#### Test 2: Create Case via API
```bash
curl -X POST 'https://espocrm-dev-220642639797.us-central1.run.app/api/v1/Case' \
  -u 'admin:Q2fp120dbL3BafWK' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "API Test - Loan inquiry",
    "type": "Inquiry",
    "priority": "Normal",
    "contactId": "6950207486d1c5836",
    "cCustomerType": "Individual",
    "cProductType": "Personal Loan",
    "description": "Test case creation via API",
    "status": "Open"
  }'
```

#### Test 3: Status Transitions
```
1. Create case (status: Open)
   ✓ Auto-assigned
   ✓ Email sent
   
2. Update to In Progress
   ✓ No additional actions
   
3. Update to Escalated
   ✓ Reassigned to supervisor
   ✓ Supervisor notified
   
4. Update to Resolved
   ✓ Resolution email sent
   ✓ Timer started (7 days)
   
5. Wait or manually update to Closed
   ✓ Closure email sent
```

---

## Field Mapping Reference

| UI Label | API Field Name | Type | Required | Your Requirement |
|----------|----------------|------|----------|------------------|
| Case ID | `number` | Auto-increment | Yes | Case ID |
| Case Number | `cCaseNumber` | Varchar | Auto | - |
| Subject | `name` | Varchar | Yes | - |
| Customer Name | `contactName` | Link | No | Customer Name |
| Customer Type | `cCustomerType` | Enum | No | Customer Type |
| Product Type | `cProductType` | Enum | No | Product Type (if applicable) |
| Case Category | `type` | Enum | Yes | Case Category |
| Case Status | `status` | Enum | Yes | Case Status |
| Priority | `priority` | Enum | Yes | Priority |
| Branch | `cBranchName` | Link | No | Branch |
| Assigned Officer | `assignedUserName` | Link | Yes | Assigned Officer |

---

## Assignment Rules Configuration

### Rule 1: Branch-Based (Round-Robin)
```
Administration → Workflow → Create

Name: Assign to Branch Team
Target Entity: Case
Trigger: After record created
Conditions: cBranchId is not null

Actions:
  1. Apply Assignment Rule
     - Target: Round-Robin
     - Team: Get from formula → record\attribute('Branch', entity\attribute('cBranchId'), 'teamId')
```

### Rule 2: Category-Based
```
Service Request → Customer Service Team (Round-Robin)
Complaint → Complaints Team (Least-Busy)
Inquiry → General Inquiry Team (Round-Robin)

This is handled automatically by BPM Workflow:
"Case: Auto-Assignment & Acknowledgment"
```

---

## API Quick Reference

### Create Case
```bash
POST /api/v1/Case
{
  "name": "Subject",
  "type": "Service|Complaint|Inquiry",
  "priority": "Low|Normal|High|Urgent",
  "contactId": "CONTACT_ID",
  "cCustomerType": "Individual|Corporate|SME|Micro Finance",
  "cProductType": "Personal Loan|Vehicle Loan|...",
  "cBranchId": "BRANCH_ID",
  "description": "Description text",
  "status": "Open"
}
```

### Update Status
```bash
PUT /api/v1/Case/{CASE_ID}
{
  "status": "In Progress|Pending Customer|Escalated|Resolved|Closed"
}
```

### Get Case
```bash
GET /api/v1/Case/{CASE_ID}
```

### List Cases by Status
```bash
GET /api/v1/Case?where[0][type]=equals&where[0][attribute]=status&where[0][value]=Open
```

---

## Troubleshooting

### Issue: Custom fields not showing
**Solution:**
1. Administration → Clear Cache
2. Hard refresh browser (Ctrl+Shift+R)
3. Rebuild: `php rebuild.php` (server access required)

### Issue: BPM not triggering
**Solution:**
1. Check workflow is Active
2. Verify trigger conditions match
3. Administration → Jobs → Check for failed jobs
4. Enable BPM logging in config

### Issue: Assignment not working
**Solution:**
1. Verify teams exist and have members
2. Check user permissions
3. Verify team assignment in workflow
4. Test manually first

### Issue: Emails not sending
**Solution:**
1. Administration → Email Accounts → Verify SMTP
2. Check email templates exist
3. Test email sending manually
4. Check email queue in Jobs

---

## Rollback Plan

If issues occur:

1. **Disable workflows**
   ```
   Administration → Flowcharts → Uncheck "Is Active" for all case workflows
   ```

2. **Revert field changes**
   ```
   Administration → Entity Manager → Case → Fields
   Delete custom fields: cCustomerType, cProductType
   Restore original type/status options
   ```

3. **Clear cache**
   ```
   Administration → Clear Cache
   ```

---

## Success Criteria

- [ ] All 3 custom fields created and visible
- [ ] Status and Category options updated
- [ ] All 3 BPM workflows active and tested
- [ ] Assignment rules working correctly
- [ ] Email notifications sending
- [ ] API integration tested
- [ ] Users trained on new fields
- [ ] No errors in system logs

---

## Support Contacts

**Technical Issues:** IT Support  
**Business Questions:** Operations Manager  
**Training:** System Administrator  

**Documentation:** 
- Main guide: case_architecture_implementation.md
- Workflows: case_workflows_complete.csv
- Journeys: case_customer_journeys.md
